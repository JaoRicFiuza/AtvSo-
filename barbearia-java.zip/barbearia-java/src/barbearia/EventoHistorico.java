package barbearia;

import java.util.List;

/**
 * Fotografia completa (snapshot) da barbearia em um passo da simulação.
 * Permite reproduzir e navegar pelo histórico depois da execução.
 * 'cor' é o código ANSI 256 usado na tag de status.
 */
record EventoHistorico(
        int passo,
        String horario,
        String ator,
        String tagStatus,
        int cor,
        String acao,
        String semaforoOp,
        String explicacao,
        int clienteEmCorte,
        int waiting,
        int totalCadeiras,
        List<Integer> filaEspera,
        int atendidos,
        int desistiram) {
}
