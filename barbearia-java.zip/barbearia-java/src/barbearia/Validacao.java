package barbearia;

import static barbearia.Barbearia.LARGURA_CAIXA_INT;
import static barbearia.Barbearia.LARGURA_TOTAL;
import static barbearia.Barbearia.corAmarelo;
import static barbearia.Barbearia.corBranco;
import static barbearia.Barbearia.corCinza;
import static barbearia.Barbearia.corDestaque;
import static barbearia.Barbearia.corTextoEscuro;
import static barbearia.Barbearia.corTitulo;
import static barbearia.Barbearia.corVerde;
import static barbearia.Barbearia.corVermelho;
import static barbearia.Barbearia.dormir;
import static barbearia.Barbearia.limparTela;
import static barbearia.Barbearia.renderizarSnapshotBarbearia;
import static barbearia.Estilo.fmt;

import java.io.BufferedReader;
import java.time.Duration;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Simulações em 3 etapas, navegador de histórico e suíte de testes (validacao.go). */
final class Validacao {

    private Validacao() {
    }

    /** Simulação padrão: Etapa 1 (ao vivo), Etapa 2 (tabela) e Etapa 3 (replay). */
    static void executarSimulacaoPadrao(BufferedReader leitor) {
        Barbearia b = new Barbearia(3, Duration.ofMillis(180), true);
        lancarThread(new Barbeiro(b));
        dormir(Duration.ofMillis(40));

        WaitGroup wg = new WaitGroup();

        // Onda 1: 6 clientes (1 corta, 3 sentam e 2 desistem por lotação)
        for (int id = 1; id <= 6; id++) {
            wg.add(1);
            lancarThread(new Cliente(b, id, wg));
            dormir(Duration.ofMillis(25));
        }
        wg.esperar();
        dormir(Duration.ofMillis(60));

        // Onda 2: o barbeiro voltou a dormir; mais 2 clientes o acordam
        for (int id = 7; id <= 8; id++) {
            wg.add(1);
            lancarThread(new Cliente(b, id, wg));
            dormir(Duration.ofMillis(40));
        }
        wg.esperar();
        dormir(Duration.ofMillis(30));

        b.mutex.down();
        b.exibirLogs = false;
        b.mutex.up();

        b.reproduzirAoVivo(Duration.ofMillis(2000));

        System.out.println();
        String avisoFim = Estilo.novo().negrito().fg(corVerde).borda(corVerde).padding(0, 2)
                .largura(LARGURA_CAIXA_INT).render(
                        "ETAPA 1 CONCLUIDA! Todos os 8 clientes foram processados.\n"
                                + "Pressione [ENTER] para abrir a ETAPA 2 (Historico Completo) e a ETAPA 3 (Navegador Passo a Passo)...");
        System.out.println(avisoFim);
        Main.lerLinha(leitor);

        navegarPeloHistorico(leitor, b, 8, 3);
    }

    /** Simulação customizada: o usuário escolhe os parâmetros. */
    static void executarSimulacaoCustomizada(BufferedReader leitor) {
        limparTela();
        String titulo = Estilo.novo().negrito().fg(corBranco).bg(24).padding(0, 2).largura(LARGURA_TOTAL)
                .render("SIMULACAO CUSTOMIZADA (DEFINA OS PARAMETROS DA BARBEARIA)");
        System.out.println(titulo);
        System.out.println();

        int cadeiras = Main.lerInteiro(leitor, "  1. Quantas cadeiras de espera (N)?          [Padrao: 4]: ", 4, 1, 6);
        int clientes = Main.lerInteiro(leitor, "  2. Quantos clientes vao chegar?             [Padrao: 8]: ", 8, 1, 30);
        int corteMs = Main.lerInteiro(leitor, "  3. Tempo de cada corte (em ms)?             [Padrao: 200]: ", 200, 30, 5000);
        int chegadaMs = Main.lerInteiro(leitor, "  4. Intervalo entre chegadas (em ms)?        [Padrao: 40]: ", 40, 10, 5000);
        int pausaSeg = Main.lerInteiro(leitor, "  5. Tempo de exibicao de cada passo (em s)?  [Padrao: 2]: ", 2, 1, 10);

        Barbearia b = new Barbearia(cadeiras, Duration.ofMillis(corteMs), true);
        lancarThread(new Barbeiro(b));
        dormir(Duration.ofMillis(40));

        WaitGroup wg = new WaitGroup();
        for (int id = 1; id <= clientes; id++) {
            wg.add(1);
            lancarThread(new Cliente(b, id, wg));
            dormir(Duration.ofMillis(chegadaMs));
        }
        wg.esperar();
        dormir(Duration.ofMillis(30));

        b.mutex.down();
        b.exibirLogs = false;
        b.mutex.up();

        b.reproduzirAoVivo(Duration.ofSeconds(pausaSeg));

        System.out.println();
        String avisoFim = Estilo.novo().negrito().fg(corVerde).borda(corVerde).padding(0, 2)
                .largura(LARGURA_CAIXA_INT).render(
                        "ETAPA 1 CONCLUIDA! Pressione [ENTER] para ver o Historico Completo e o Navegador Passo a Passo...");
        System.out.println(avisoFim);
        Main.lerLinha(leitor);

        navegarPeloHistorico(leitor, b, clientes, cadeiras);
    }

    /** Etapa 2: tabela com todos os eventos numerados. */
    static void exibirTabelaHistoricoCompleto(Barbearia b, int totalClientes, int cadeiras) {
        limparTela();

        System.out.println(Estilo.novo().negrito().fg(corBranco).bg(24).padding(0, 2).largura(LARGURA_TOTAL)
                .render("ETAPA 2/3: HISTORICO COMPLETO DE EVENTOS DA SIMULACAO"));
        System.out.println();

        System.out.println(Estilo.novo().negrito().fg(corTitulo).render(
                "  PASSO | HORARIO      | THREAD       | STATUS     | O QUE ACONTECEU                | SEMAFOROS ACIONADOS"));
        System.out.println(Estilo.novo().fg(corCinza).render("-".repeat(LARGURA_TOTAL)));

        for (EventoHistorico ev : b.historico) {
            String tag = Estilo.novo().negrito().fg(corTextoEscuro).bg(ev.cor())
                    .render(fmt(" %-8s ", ev.tagStatus()));
            String sem = Estilo.novo().fg(corDestaque).render(ev.semaforoOp());
            System.out.println(fmt("   #%02d  | %s | %-12s | %s | %-30s | %s",
                    ev.passo(), ev.horario(), ev.ator(), tag, ev.acao(), sem));
        }

        String resumo = fmt(
                "RESUMO DA EXECUCAO:   Total de Clientes: %d   |   Atendidos: %d   |   Desistiram (Lotado): %d   |   Pico na Espera: %d/%d",
                totalClientes, b.atendidos, b.desistiram, b.maximoWaiting, cadeiras);
        String caixaResumo = Estilo.novo().negrito().fg(corVerde).borda(corVerde).padding(0, 2)
                .largura(LARGURA_CAIXA_INT).render(resumo);
        System.out.println();
        System.out.println(caixaResumo);
    }

    /** Etapa 2 (tabela) + Etapa 3 (replay passo a passo). */
    static void navegarPeloHistorico(BufferedReader leitor, Barbearia b, int totalClientes, int cadeiras) {
        int totalPassos = b.historico.size();
        if (totalPassos == 0) {
            return;
        }

        exibirTabelaHistoricoCompleto(b, totalClientes, cadeiras);

        String convite = Estilo.novo().borda(corTitulo).padding(0, 2).largura(LARGURA_CAIXA_INT).render(
                Estilo.novo().negrito().fg(corTitulo).render("ETAPA 3/3: QUER NAVEGAR PASSO A PASSO PELA BARBEARIA (MODO REPLAY)?")
                        + "\n  * Digite "
                        + Estilo.novo().negrito().fg(corVerde).render("[ENTER]")
                        + " (ou um numero de "
                        + Estilo.novo().negrito().fg(corAmarelo).render("1")
                        + " a "
                        + Estilo.novo().negrito().fg(corAmarelo).render(String.valueOf(totalPassos))
                        + ") para abrir o "
                        + Estilo.novo().negrito().fg(corBranco).render("Navegador Interativo Passo a Passo")
                        + "\n  * Digite "
                        + Estilo.novo().negrito().fg(corVermelho).render("[0]")
                        + " para voltar direto ao Menu Principal");
        System.out.println(convite);
        Main.pedir("\n  Sua escolha ([ENTER] = Iniciar no Passo #01 | [1.." + totalPassos + "] = Ir p/ Passo | [0] = Menu): ");

        String escolha = Main.lerLinha(leitor).trim().toUpperCase(Locale.ROOT);
        if (escolha.equals("0")) {
            return;
        }

        int indiceAtual = 0; // Passo #01
        Integer num = Main.tentarInteiro(escolha);
        if (num != null && num >= 1 && num <= totalPassos) {
            indiceAtual = num - 1;
        }

        while (true) {
            EventoHistorico ev = b.historico.get(indiceAtual);
            String tituloReplay = fmt("ETAPA 3/3: NAVEGADOR DE HISTORICO (REPLAY PASSO A PASSO — PASSO %02d DE %02d)",
                    ev.passo(), totalPassos);
            renderizarSnapshotBarbearia(tituloReplay, ev, totalPassos);

            String antStr = "(Inicio da simulacao)";
            if (indiceAtual > 0) {
                EventoHistorico ant = b.historico.get(indiceAtual - 1);
                antStr = fmt("#%02d %s: %s", ant.passo(), ant.ator(), ant.acao());
            }
            String proxStr = "(Fim da simulacao)";
            if (indiceAtual < totalPassos - 1) {
                EventoHistorico prox = b.historico.get(indiceAtual + 1);
                proxStr = fmt("#%02d %s: %s", prox.passo(), prox.ator(), prox.acao());
            }
            String linhaDoTempo = fmt("  << Anterior: %-34s  |  Proximo: %-34s >>", antStr, proxStr);
            System.out.println(Estilo.novo().fg(corCinza).render(linhaDoTempo));

            String controles = fmt(
                    "CONTROLES DO REPLAY:   %s Proximo Passo   |   %s Passo Anterior   |   %s Ir p/ Passo   |   %s Ver Tabela Completa   |   %s Sair p/ Menu",
                    Estilo.novo().negrito().fg(corVerde).render("[ENTER / P]"),
                    Estilo.novo().negrito().fg(corAmarelo).render("[A]"),
                    Estilo.novo().negrito().fg(corTitulo).render("[1.." + totalPassos + "]"),
                    Estilo.novo().negrito().fg(corDestaque).render("[H]"),
                    Estilo.novo().negrito().fg(corVermelho).render("[0]"));
            System.out.println(Estilo.novo().borda(corTitulo).padding(0, 2).largura(LARGURA_CAIXA_INT).render(controles));
            Main.pedir("  Comando de navegacao: ");

            String cmdStr = Main.lerLinhaOuNull(leitor);
            if (cmdStr == null) {
                return;
            }
            String cmd = cmdStr.trim().toUpperCase(Locale.ROOT);

            switch (cmd) {
                case "", "P", "N" -> {
                    if (indiceAtual < totalPassos - 1) {
                        indiceAtual++;
                    }
                }
                case "A", "V" -> {
                    if (indiceAtual > 0) {
                        indiceAtual--;
                    }
                }
                case "H", "T" -> {
                    exibirTabelaHistoricoCompleto(b, totalClientes, cadeiras);
                    Main.pedir("\n  Pressione [ENTER] para voltar ao Passo #" + fmt("%02d", indiceAtual + 1)
                            + " do Replay (ou digite 0 para sair): ");
                    String voltar = Main.lerLinha(leitor);
                    if (voltar.trim().equals("0")) {
                        return;
                    }
                }
                case "0", "S" -> {
                    return;
                }
                default -> {
                    Integer passo = Main.tentarInteiro(cmd);
                    if (passo != null && passo >= 1 && passo <= totalPassos) {
                        indiceAtual = passo - 1;
                    }
                }
            }
        }
    }

    // ========================================================================
    // SUÍTE DE TESTES DE VALIDAÇÃO (Opção 3 do menu)
    // ========================================================================

    static void executarTestesValidacao(BufferedReader leitor) {
        limparTela();
        System.out.println(Estilo.novo().negrito().fg(corBranco).bg(24).padding(0, 2).largura(LARGURA_TOTAL)
                .render("SUITE DE VALIDACAO AUTOMATIZADA DO MECANISMO DE SINCRONIZACAO"));
        System.out.println();

        boolean t1 = testeDormirAcordar();
        boolean t2 = testeLimiteCadeiras();
        boolean t3 = testeEstresseSemDeadlock();

        String msgFinal;
        int corFinal;
        if (t1 && t2 && t3) {
            corFinal = corVerde;
            msgFinal = "RESULTADO FINAL: APROVADO!\n"
                    + "  * Exclusao Mutua (mutex)     : 0 violacoes de regiao critica\n"
                    + "  * Limite do Buffer (waiting) : 0 <= waiting <= N respeitado em 100% dos casos\n"
                    + "  * Prevencao de Deadlock      : Todas as threads finalizaram sem travamento";
        } else {
            corFinal = corVermelho;
            msgFinal = "RESULTADO FINAL: FALHA EM ALGUM TESTE DE VALIDACAO";
        }

        System.out.println(Estilo.novo().negrito().fg(corFinal).borda(corFinal).padding(0, 2)
                .largura(LARGURA_CAIXA_INT).render(msgFinal));
        Main.aguardarEnter(leitor);
    }

    static void renderizarCardTeste(String titulo, String cenario, String resultado, boolean passou) {
        int cor = corVerde;
        String status = " PASSOU ";
        if (!passou) {
            cor = corVermelho;
            status = " FALHOU ";
        }
        String badge = Estilo.novo().negrito().fg(corTextoEscuro).bg(cor).render(status);
        System.out.println(Estilo.novo().borda(cor).padding(0, 2).largura(LARGURA_CAIXA_INT).render(
                badge + "  " + Estilo.novo().negrito().fg(corBranco).render(titulo)
                        + "\n  * Cenario  : " + cenario
                        + "\n  * Resultado: " + Estilo.novo().fg(cor).render(resultado)));
    }

    static boolean testeDormirAcordar() {
        final int cadeiras = 3;
        final int total = 5;
        Barbearia b = new Barbearia(cadeiras, Duration.ofMillis(25), false);
        lancarThread(new Barbeiro(b));

        WaitGroup wg = new WaitGroup();
        for (int id = 1; id <= total; id++) {
            wg.add(1);
            lancarThread(new Cliente(b, id, wg));
            dormir(Duration.ofMillis(55));
        }
        wg.esperar();

        boolean passou = b.atendidos == total && b.desistiram == 0 && b.violacoes == 0 && b.waiting == 0;
        renderizarCardTeste(
                "TESTE 1: Sincronizacao Dormir e Acordar (customers.Down / customers.Up)",
                "5 clientes chegam espacados; o barbeiro dorme entre eles e deve atender todos.",
                fmt("Atendidos = %d/%d | Desistencias = %d | Violacoes de Regiao Critica = %d",
                        b.atendidos, total, b.desistiram, b.violacoes),
                passou);
        return passou;
    }

    static boolean testeLimiteCadeiras() {
        final int cadeiras = 4;
        final int total = 12;
        Barbearia b = new Barbearia(cadeiras, Duration.ofMillis(100), false);
        lancarThread(new Barbeiro(b));
        dormir(Duration.ofMillis(20));

        WaitGroup wg = new WaitGroup();
        for (int id = 1; id <= total; id++) {
            wg.add(1);
            lancarThread(new Cliente(b, id, wg));
        }
        wg.esperar();

        boolean passou = (b.atendidos + b.desistiram == total) && (b.desistiram > 0)
                && (b.maximoWaiting <= cadeiras) && (b.violacoes == 0) && (b.waiting == 0);
        renderizarCardTeste(
                "TESTE 2: Controle de Lotacao das Cadeiras (waiting <= N)",
                "12 clientes chegam simultaneamente disputando N=4 cadeiras de espera.",
                fmt("Atendidos = %d | Desistiram (Lotado) = %d | Pico na Espera = %d/%d | Violacoes = %d",
                        b.atendidos, b.desistiram, b.maximoWaiting, cadeiras, b.violacoes),
                passou);
        return passou;
    }

    static boolean testeEstresseSemDeadlock() {
        final int cadeiras = 5;
        final int total = 50;
        Barbearia b = new Barbearia(cadeiras, Duration.ofMillis(10), false);
        lancarThread(new Barbeiro(b));

        WaitGroup wg = new WaitGroup();
        CountDownLatch concluido = new CountDownLatch(1);

        lancarThread(() -> {
            for (int id = 1; id <= total; id++) {
                wg.add(1);
                lancarThread(new Cliente(b, id, wg));
                if (id % 7 == 0) {
                    dormir(Duration.ofMillis(15));
                }
            }
            wg.esperar();
            concluido.countDown();
        });

        if (aguardar(concluido, 5000)) {
            boolean passou = (b.atendidos + b.desistiram == total) && (b.violacoes == 0)
                    && (b.maximoWaiting <= cadeiras) && (b.waiting == 0);
            renderizarCardTeste(
                    "TESTE 3: Estresse com 50 Threads Concorrentes (Anti-Deadlock e Race Condition)",
                    "50 threads clientes concorrem simultaneamente com verificacao de timeout.",
                    fmt("Total Processado = %d/%d (Atendidos: %d + Desistiram: %d) | Deadlock = Nao",
                            b.atendidos + b.desistiram, total, b.atendidos, b.desistiram),
                    passou);
            return passou;
        }

        renderizarCardTeste(
                "TESTE 3: Estresse com 50 Threads Concorrentes",
                "50 threads clientes concorrem simultaneamente.",
                "DEADLOCK DETECTADO (Timeout excedido!)",
                false);
        return false;
    }

    /** Equivalente ao select com time.After do Go. */
    private static boolean aguardar(CountDownLatch latch, long milissegundos) {
        try {
            return latch.await(milissegundos, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    /** Equivalente ao 'go f()' do Go: thread daemon, que não impede o encerramento do programa. */
    private static void lancarThread(Runnable tarefa) {
        Thread t = new Thread(tarefa);
        t.setDaemon(true);
        t.start();
    }
}
