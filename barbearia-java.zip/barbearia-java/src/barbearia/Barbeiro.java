package barbearia;

import static barbearia.Barbearia.corAzul;
import static barbearia.Barbearia.corVerde;
import static barbearia.Barbearia.dormir;
import static barbearia.Estilo.fmt;

import java.time.Duration;

/**
 * Linha de execução da thread do Barbeiro (barbeiro.go).
 * Segue o método 'barber' de Tanenbaum (pág. 6):
 *   1. customers.down() — dorme se não há clientes;
 *   2. mutex.down() — entra na região crítica;
 *   3. waiting-- e barbers.up() — chama um cliente;
 *   4. mutex.up() — sai da região crítica;
 *   5. corta o cabelo fora da região crítica.
 */
final class Barbeiro implements Runnable {

    private final Barbearia b;

    Barbeiro(Barbearia b) {
        this.b = b;
    }

    @Override
    public void run() {
        while (true) {
            // Se não há clientes esperando, registra no painel que o barbeiro vai dormir
            b.mutex.down();
            if (b.waiting == 0) {
                b.clienteEmCorte = 0;
                b.registrarEvento(
                        "Barbeiro",
                        "DORMINDO",
                        corAzul,
                        "Sem clientes, caiu no sono",
                        "customers.Down()",
                        "Nao ha clientes na espera (waiting == 0). O barbeiro faz customers.Down() e DORME sem gastar CPU.");
            }
            b.mutex.up();

            // 1. Bloqueia em 'customers' (dorme se customers == 0)
            b.customers.down();

            // 2. Região crítica para atualizar 'waiting'
            b.mutex.down();

            int clienteAtual = b.filaEspera.remove(0);
            b.waiting--;
            b.clienteEmCorte = clienteAtual;
            b.atendidos++;
            b.validarEstado();

            // 3. Sinaliza que o barbeiro está pronto para cortar
            b.barbers.up();

            b.registrarEvento(
                    "Barbeiro",
                    "CORTANDO",
                    corVerde,
                    fmt("Chamou Cliente #%02d p/ corte", clienteAtual),
                    "waiting-- | barbers.Up()",
                    fmt("Entrou em mutex.Down(), tirou Cliente #%02d da espera (waiting=%d), fez barbers.Up() e liberou mutex.Up().",
                            clienteAtual, b.waiting));

            // 4. Sai da região crítica antes de cortar (evita deadlock)
            b.mutex.up();

            // 5. Corta o cabelo fora da região crítica
            cortarCabelo(clienteAtual);
        }
    }

    private void cortarCabelo(int idCliente) {
        dormir(b.tempoCorte);

        b.mutex.down();
        b.clienteEmCorte = 0;
        b.registrarEvento(
                "Barbeiro",
                "PRONTO",
                corAzul,
                fmt("Terminou corte do Cli #%02d", idCliente),
                "Fim de cortarCabelo()",
                fmt("O barbeiro concluiu o corte do Cliente #%02d e vai verificar se ha outro cliente na espera.", idCliente));
        b.mutex.up();

        // Pequena pausa para o cliente levantar da cadeira antes de chamar o próximo
        dormir(Duration.ofMillis(15));
    }
}
