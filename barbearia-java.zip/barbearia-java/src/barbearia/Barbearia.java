package barbearia;

import static barbearia.Estilo.fmt;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Recursos compartilhados, os 3 semáforos e a visualização (barbearia.go).
 * Modelagem de Tanenbaum (pág. 6): 1 variável 'waiting' e 3 semáforos
 * 'customers' (0), 'barbers' (0) e 'mutex' (1).
 */
final class Barbearia {

    // Larguras padronizadas (mesmas do original)
    static final int LARGURA_TOTAL = 114;
    static final int LARGURA_CAIXA_INT = 112;
    static final int LARGURA_MEIA_CAIXA = 54;

    // Paleta (códigos ANSI 256 do original)
    static final int corTitulo = 39;
    static final int corVerde = 42;
    static final int corAmarelo = 214;
    static final int corVermelho = 196;
    static final int corAzul = 45;
    static final int corCinza = 244;
    static final int corBranco = 255;
    static final int corDestaque = 213;
    static final int corTextoEscuro = 16;

    static final boolean WINDOWS =
            System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");

    private static final DateTimeFormatter FORMATO_HORA = DateTimeFormatter.ofPattern("HH:mm:ss.SSS");

    // Recursos compartilhados
    int waiting;                        // clientes nas cadeiras (0 <= waiting <= totalCadeiras)
    final int totalCadeiras;            // N cadeiras de espera
    final List<Integer> filaEspera;     // IDs dos clientes sentados
    int clienteEmCorte;                 // ID na cadeira do barbeiro (0 = ninguém)

    // Os 3 semáforos obrigatórios
    final Semaforo customers;
    final Semaforo barbers;
    final Semaforo mutex;

    // Configuração e histórico
    final Duration tempoCorte;
    boolean exibirLogs;
    final List<EventoHistorico> historico = new ArrayList<>();

    // Contadores de validação (sempre atualizados dentro da região crítica do mutex)
    int atendidos;
    int desistiram;
    int maximoWaiting;
    int violacoes;

    Barbearia(int numCadeiras, Duration tempoCorte, boolean exibirLogs) {
        this.waiting = 0;
        this.totalCadeiras = numCadeiras;
        this.filaEspera = new ArrayList<>(numCadeiras);
        this.customers = new Semaforo(0);
        this.barbers = new Semaforo(0);
        this.mutex = new Semaforo(1);
        this.tempoCorte = tempoCorte;
        this.exibirLogs = exibirLogs;
    }

    void validarEstado() {
        if (waiting < 0 || waiting > totalCadeiras) {
            violacoes++;
        }
        if (waiting > maximoWaiting) {
            maximoWaiting = waiting;
        }
    }

    /** Salva a fotografia completa do passo (chamar sempre dentro da região crítica do mutex). */
    void registrarEvento(String ator, String tagStatus, int cor, String acao, String semaforoOp, String explicacao) {
        if (!exibirLogs) {
            return;
        }
        historico.add(new EventoHistorico(
                historico.size() + 1,
                LocalTime.now().format(FORMATO_HORA),
                ator,
                tagStatus,
                cor,
                acao,
                semaforoOp,
                explicacao,
                clienteEmCorte,
                waiting,
                totalCadeiras,
                List.copyOf(filaEspera),
                atendidos,
                desistiram));
    }

    /** Exibe cada evento capturado em ritmo pausado (Etapa 1). */
    void reproduzirAoVivo(Duration pausaPorPasso) {
        int total = historico.size();
        for (EventoHistorico ev : historico) {
            String titulo = fmt(
                    "ETAPA 1/3: VISUALIZACAO AO VIVO DA BARBEARIA (Passo %02d de %02d — Ritmo: %.1fs por evento)",
                    ev.passo(), total, pausaPorPasso.toMillis() / 1000.0);
            renderizarSnapshotBarbearia(titulo, ev, total);
            dormir(pausaPorPasso);
        }
    }

    /** Desenha a planta da barbearia e a explicação de um passo (Etapa 1 ao vivo e Etapa 3 no replay). */
    static void renderizarSnapshotBarbearia(String tituloTopo, EventoHistorico ev, int totalPassos) {
        limparTela();

        Estilo estiloCabecalho = Estilo.novo().negrito().fg(corBranco).bg(24).padding(0, 2).largura(LARGURA_TOTAL);
        System.out.println(estiloCabecalho.render(tituloTopo));

        // 1. Cadeira do barbeiro
        String statusBarbeiro;
        String detalheBarbeiro;
        int corBarbeiro;
        if (ev.clienteEmCorte() > 0) {
            corBarbeiro = corVerde;
            statusBarbeiro = fmt(" CORTANDO CLIENTE #%02d ", ev.clienteEmCorte());
            detalheBarbeiro = "Barbeiro ocupado no corte (mutex livre)";
        } else {
            corBarbeiro = corAzul;
            statusBarbeiro = " DORMINDO NA CADEIRA (zZz) ";
            detalheBarbeiro = "Barbeiro bloqueado em customers.Down()";
        }

        String badgeBarbeiro = Estilo.novo().negrito().fg(corTextoEscuro).bg(corBarbeiro)
                .padding(0, 1).render(statusBarbeiro);

        String caixaBarbeiro = Estilo.novo().borda(corBarbeiro).padding(0, 2)
                .largura(LARGURA_MEIA_CAIXA).altura(5).render(
                        Estilo.novo().negrito().fg(corBranco).render("1. CADEIRA DO BARBEIRO")
                                + "\n\n" + badgeBarbeiro + "\n"
                                + Estilo.novo().fg(corCinza).render(detalheBarbeiro));

        // 2. Sala de espera
        List<String> cadeiras = new ArrayList<>();
        for (int i = 0; i < ev.totalCadeiras(); i++) {
            if (i < ev.filaEspera().size()) {
                int idCli = ev.filaEspera().get(i);
                cadeiras.add(Estilo.novo().negrito().fg(corTextoEscuro).bg(corAmarelo).padding(0, 1)
                        .render(fmt("Cad.%d: CLI #%02d", i + 1, idCli)));
            } else {
                cadeiras.add(Estilo.novo().fg(corCinza).padding(0, 1)
                        .render(fmt("[Cad.%d: LIVRE]", i + 1)));
            }
        }
        String linhaCadeiras = String.join(" ", cadeiras);

        String subtituloEspera = fmt("Variavel compartilhada: waiting = %d de %d cadeiras",
                ev.waiting(), ev.totalCadeiras());
        if (ev.waiting() == ev.totalCadeiras()) {
            subtituloEspera += " (LOTADA!)";
        }

        String caixaEspera = Estilo.novo().borda(corAmarelo).padding(0, 2)
                .largura(LARGURA_MEIA_CAIXA).altura(5).render(
                        Estilo.novo().negrito().fg(corBranco).render("2. SALA DE ESPERA (N CADEIRAS)")
                                + "\n\n" + linhaCadeiras + "\n"
                                + Estilo.novo().fg(corCinza).render(subtituloEspera));

        System.out.println(Estilo.juntarHorizontal(caixaBarbeiro, "  ", caixaEspera));

        // 3. Placar
        String infoPasso = fmt("Passo %02d de %02d", ev.passo(), totalPassos);
        String linhaPlacar = fmt("%s   |   %s   |   %s   |   %s",
                Estilo.novo().negrito().fg(corTitulo).render(infoPasso + " (" + ev.horario() + ")"),
                Estilo.novo().negrito().fg(corVerde).render(fmt("Atendidos: %d", ev.atendidos())),
                Estilo.novo().negrito().fg(corAmarelo).render(fmt("Esperando (waiting): %d/%d", ev.waiting(), ev.totalCadeiras())),
                Estilo.novo().negrito().fg(corVermelho).render(fmt("Foram Embora (Lotado): %d", ev.desistiram())));

        String caixaPlacar = Estilo.novo().borda(corCinza).padding(0, 2).largura(LARGURA_CAIXA_INT)
                .render(linhaPlacar);
        System.out.println(caixaPlacar);

        // 4. Quadro didático
        String badgeStatus = Estilo.novo().negrito().fg(corTextoEscuro).bg(ev.cor()).padding(0, 1)
                .render(ev.tagStatus());
        String linhaAtor = badgeStatus + "  "
                + Estilo.novo().negrito().fg(corBranco).render(ev.ator()) + " — "
                + Estilo.novo().negrito().fg(ev.cor()).render(ev.acao());
        String linhaSemaforo = "Semaforos / Variaveis acionados: "
                + Estilo.novo().negrito().fg(corDestaque).render(ev.semaforoOp());
        String linhaExplicacao = "Explicacao: " + Estilo.novo().fg(corBranco).render(ev.explicacao());

        String caixaExplicacao = Estilo.novo().borda(corDestaque).padding(0, 2).largura(LARGURA_CAIXA_INT)
                .render(linhaAtor + "\n\n" + linhaSemaforo + "\n" + linhaExplicacao);
        System.out.println(caixaExplicacao);
    }

    static void limparTela() {
        if (WINDOWS) {
            try {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } catch (IOException | InterruptedException ignorado) {
                // Assim como no original, falhas ao limpar a tela são ignoradas.
            }
        } else {
            System.out.print("\033[H\033[2J");
            System.out.flush();
        }
    }

    static void dormir(Duration duracao) {
        try {
            Thread.sleep(duracao.toMillis());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
