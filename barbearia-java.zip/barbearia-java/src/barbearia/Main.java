package barbearia;

import static barbearia.Barbearia.LARGURA_CAIXA_INT;
import static barbearia.Barbearia.LARGURA_MEIA_CAIXA;
import static barbearia.Barbearia.LARGURA_TOTAL;
import static barbearia.Barbearia.corAmarelo;
import static barbearia.Barbearia.corAzul;
import static barbearia.Barbearia.corBranco;
import static barbearia.Barbearia.corCinza;
import static barbearia.Barbearia.corDestaque;
import static barbearia.Barbearia.corTitulo;
import static barbearia.Barbearia.corVerde;
import static barbearia.Barbearia.corVermelho;
import static barbearia.Barbearia.limparTela;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

/** Menu interativo e inicialização do programa (main.go). */
public final class Main {

    static {
        // Equivalente ao init() do Go: saída em UTF-8 e, no Windows, code page 65001.
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        if (Barbearia.WINDOWS) {
            try {
                new ProcessBuilder("cmd", "/c", "chcp 65001")
                        .redirectOutput(ProcessBuilder.Redirect.DISCARD)
                        .redirectError(ProcessBuilder.Redirect.DISCARD)
                        .start()
                        .waitFor();
            } catch (IOException | InterruptedException ignorado) {
                // Assim como no original, falhas aqui são ignoradas.
            }
        }
    }

    private Main() {
    }

    public static void main(String[] args) {
        BufferedReader leitor = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));

        while (true) {
            limparTela();

            String cabecalho = Estilo.novo().negrito().fg(corBranco).bg(24).padding(0, 2).largura(LARGURA_TOTAL)
                    .render("PUC MINAS - SISTEMAS OPERACIONAIS | TRABALHO PRATICO 1 (PARTE II - ITEM B)\n"
                            + "PROBLEMA DO BARBEIRO DORMINHOCO EM JAVA (SEMAFOROS IMPLEMENTADOS NA UNHA)");
            System.out.println(cabecalho);

            String textoHistoria = Estilo.novo().negrito().fg(corTitulo).render("HISTORIA DO PROBLEMA (Tanenbaum, Fig. 1.20)")
                    + "\n\n"
                    + "A barbearia tem 1 barbeiro e N cadeiras:\n"
                    + "* Sem clientes: barbeiro DORME na cadeira.\n"
                    + "* Primeiro cliente: ACORDA o barbeiro.\n"
                    + "* Barbeiro ocupado e ha vaga (waiting < N):\n"
                    + "  o cliente SENTA na espera e aguarda a vez.\n"
                    + "* Sala lotada (waiting == N): VAI EMBORA.";
            String caixaHistoria = Estilo.novo().borda(corTitulo).padding(0, 2)
                    .largura(LARGURA_MEIA_CAIXA).altura(8).render(textoHistoria);

            String textoSemaforos = Estilo.novo().negrito().fg(corDestaque).render("MODELAGEM (3 SEMAFOROS + 1 VARIAVEL)")
                    + "\n\n"
                    + "* " + Estilo.novo().negrito().fg(corAmarelo).render("waiting (0..N)") + " : Clientes na sala de espera\n"
                    + "* " + Estilo.novo().negrito().fg(corAzul).render("customers = 0 ") + " : Conta clientes esperando\n"
                    + "* " + Estilo.novo().negrito().fg(corVerde).render("barbers   = 0 ") + " : Indica barbeiro disponivel\n"
                    + "* " + Estilo.novo().negrito().fg(corDestaque).render("mutex     = 1 ") + " : Exclusao mutua (waiting)\n\n"
                    + Estilo.novo().fg(corCinza).render("Anti-Deadlock: mutex.Up() ANTES de esperar!");
            String caixaSemaforos = Estilo.novo().borda(corDestaque).padding(0, 2)
                    .largura(LARGURA_MEIA_CAIXA).altura(8).render(textoSemaforos);

            System.out.println(Estilo.juntarHorizontal(caixaHistoria, "  ", caixaSemaforos));

            String op1 = Estilo.novo().negrito().fg(corVerde).render("[1]")
                    + " Executar Simulacao Visual Padrao  (Ao Vivo -> Historico Completo -> Replay Passo a Passo)";
            String op2 = Estilo.novo().negrito().fg(corAmarelo).render("[2]")
                    + " Executar Simulacao Customizada    (Escolher N cadeiras, clientes e velocidades + Replay)";
            String op3 = Estilo.novo().negrito().fg(corAzul).render("[3]")
                    + " Executar Testes de Validacao      (3 baterias de testes contra Race Condition e Deadlock)";
            String op0 = Estilo.novo().negrito().fg(corVermelho).render("[0]")
                    + " Sair do Programa";

            String caixaMenu = Estilo.novo().borda(corCinza).padding(0, 2).largura(LARGURA_CAIXA_INT).render(
                    Estilo.novo().negrito().fg(corBranco).render("MENU DE EXECUCAO INTERATIVO:")
                            + "\n\n  " + op1 + "\n  " + op2 + "\n  " + op3 + "\n  " + op0);
            System.out.println(caixaMenu);
            pedir("\n  Escolha uma opcao (0 a 3): ");

            String entrada = lerLinhaOuNull(leitor);
            if (entrada == null) {
                return;
            }
            String opcao = entrada.trim();

            switch (opcao) {
                case "1" -> Validacao.executarSimulacaoPadrao(leitor);
                case "2" -> Validacao.executarSimulacaoCustomizada(leitor);
                case "3" -> Validacao.executarTestesValidacao(leitor);
                case "0" -> {
                    System.out.println("\n  Programa encerrado.");
                    return;
                }
                default -> {
                    pedir("\n  [!] Opcao '" + opcao + "' invalida. Pressione ENTER e tente novamente...");
                    lerLinha(leitor);
                }
            }
        }
    }

    static void aguardarEnter(BufferedReader leitor) {
        pedir("\n  Pressione [ENTER] para voltar ao Menu Principal...");
        lerLinha(leitor);
    }

    static int lerInteiro(BufferedReader leitor, String pergunta, int padrao, int min, int max) {
        while (true) {
            pedir(pergunta);
            String texto = lerLinha(leitor).trim();
            if (texto.isEmpty()) {
                return padrao;
            }
            Integer valor = tentarInteiro(texto);
            if (valor != null && valor >= min && valor <= max) {
                return valor;
            }
            System.out.printf("    [!] Digite um numero entre %d e %d (ou ENTER para %d).%n", min, max, padrao);
        }
    }

    static void pedir(String texto) {
        System.out.print(texto);
        System.out.flush();
    }

    /** Lê uma linha; retorna null no fim da entrada (equivalente ao err != nil do Go). */
    static String lerLinhaOuNull(BufferedReader leitor) {
        try {
            return leitor.readLine();
        } catch (IOException e) {
            return null;
        }
    }

    /** Lê uma linha; retorna "" no fim da entrada. */
    static String lerLinha(BufferedReader leitor) {
        String linha = lerLinhaOuNull(leitor);
        return linha == null ? "" : linha;
    }

    /** Equivalente ao strconv.Atoi: retorna null quando o texto não é um inteiro. */
    static Integer tentarInteiro(String texto) {
        try {
            return Integer.parseInt(texto.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
