package barbearia;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Substituto do lipgloss (biblioteca Go usada no original), feito com códigos ANSI.
 * Suporta: negrito, cor de texto e de fundo (ANSI 256), padding, largura, altura e borda "+-|".
 */
final class Estilo {

    private static final String RESET = "\033[0m";
    private static final String REGEX_ANSI = "\u001B\\[[0-9;]*m";

    private boolean negrito;
    private int corTexto = -1;
    private int corFundo = -1;
    private int corBorda = -1;
    private boolean comBorda;
    private int padVertical;
    private int padHorizontal;
    private int largura;   // 0 = automática
    private int altura;    // 0 = automática

    private Estilo() {
    }

    static Estilo novo() {
        return new Estilo();
    }

    Estilo negrito() {
        this.negrito = true;
        return this;
    }

    Estilo fg(int cor) {
        this.corTexto = cor;
        return this;
    }

    Estilo bg(int cor) {
        this.corFundo = cor;
        return this;
    }

    Estilo padding(int vertical, int horizontal) {
        this.padVertical = vertical;
        this.padHorizontal = horizontal;
        return this;
    }

    Estilo largura(int larguraTotal) {
        this.largura = larguraTotal;
        return this;
    }

    Estilo altura(int alturaMinima) {
        this.altura = alturaMinima;
        return this;
    }

    Estilo borda(int cor) {
        this.comBorda = true;
        this.corBorda = cor;
        return this;
    }

    /** Equivalente ao fmt.Sprintf do Go, sempre com locale neutro (ponto decimal). */
    static String fmt(String formato, Object... args) {
        return String.format(Locale.ROOT, formato, args);
    }

    static int larguraVisivel(String texto) {
        return texto.replaceAll(REGEX_ANSI, "").length();
    }

    static String espacos(int n) {
        return " ".repeat(Math.max(0, n));
    }

    /** Equivalente ao lipgloss.JoinHorizontal(lipgloss.Top, ...). */
    static String juntarHorizontal(String... blocos) {
        List<String[]> colunas = new ArrayList<>();
        int alturaTotal = 0;
        int[] larguras = new int[blocos.length];

        for (int i = 0; i < blocos.length; i++) {
            String[] linhas = blocos[i].split("\n", -1);
            colunas.add(linhas);
            alturaTotal = Math.max(alturaTotal, linhas.length);
            for (String linha : linhas) {
                larguras[i] = Math.max(larguras[i], larguraVisivel(linha));
            }
        }

        StringBuilder sb = new StringBuilder();
        for (int r = 0; r < alturaTotal; r++) {
            if (r > 0) {
                sb.append('\n');
            }
            for (int i = 0; i < blocos.length; i++) {
                String[] linhas = colunas.get(i);
                String linha = r < linhas.length ? linhas[r] : "";
                sb.append(preencher(linha, larguras[i]));
            }
        }
        return sb.toString();
    }

    /** Renderiza o texto aplicando o estilo, como style.Render(texto) no Go. */
    String render(String texto) {
        String[] linhas = texto.split("\n", -1);

        int maiorLinha = 0;
        for (String linha : linhas) {
            maiorLinha = Math.max(maiorLinha, larguraVisivel(linha));
        }

        // No lipgloss, Width inclui o padding, mas não a borda.
        int w = largura > 0 ? largura : maiorLinha + 2 * padHorizontal;
        int areaTexto = w - 2 * padHorizontal;

        List<String> corpo = new ArrayList<>();
        for (int i = 0; i < padVertical; i++) {
            corpo.add(aplicar(espacos(w)));
        }
        for (String linha : linhas) {
            corpo.add(aplicar(espacos(padHorizontal) + preencher(linha, areaTexto) + espacos(padHorizontal)));
        }
        for (int i = 0; i < padVertical; i++) {
            corpo.add(aplicar(espacos(w)));
        }
        while (altura > 0 && corpo.size() < altura) {
            corpo.add(aplicar(espacos(w)));
        }

        if (!comBorda) {
            return String.join("\n", corpo);
        }

        String inicioBorda = "\033[38;5;" + corBorda + "m";
        String traco = "-".repeat(w);
        List<String> saida = new ArrayList<>();
        saida.add(inicioBorda + "+" + traco + "+" + RESET);
        for (String linha : corpo) {
            saida.add(inicioBorda + "|" + RESET + linha + inicioBorda + "|" + RESET);
        }
        saida.add(inicioBorda + "+" + traco + "+" + RESET);
        return String.join("\n", saida);
    }

    private String aplicar(String texto) {
        String prefixo = prefixo();
        if (prefixo.isEmpty()) {
            return texto;
        }
        // Um RESET interno (estilo aninhado) não pode apagar o estilo externo do resto da linha.
        return prefixo + texto.replace(RESET, RESET + prefixo) + RESET;
    }

    private String prefixo() {
        StringBuilder sb = new StringBuilder();
        if (negrito) {
            sb.append("\033[1m");
        }
        if (corTexto >= 0) {
            sb.append("\033[38;5;").append(corTexto).append('m');
        }
        if (corFundo >= 0) {
            sb.append("\033[48;5;").append(corFundo).append('m');
        }
        return sb.toString();
    }

    private static String preencher(String texto, int n) {
        int falta = n - larguraVisivel(texto);
        return falta > 0 ? texto + espacos(falta) : texto;
    }
}
