package barbearia;

import static barbearia.Barbearia.corAmarelo;
import static barbearia.Barbearia.corVerde;
import static barbearia.Barbearia.corVermelho;
import static barbearia.Barbearia.dormir;
import static barbearia.Estilo.fmt;

/**
 * Linha de execução da thread do Cliente (cliente.go).
 * Segue o método 'customer' de Tanenbaum (pág. 6):
 *   1. mutex.down() — entra na região crítica;
 *   2. se há cadeira livre: waiting++, customers.up(), mutex.up(), barbers.down() e recebe o corte;
 *   3. se está lotado: mutex.up() e vai embora.
 */
final class Cliente implements Runnable {

    private final Barbearia b;
    private final int id;
    private final WaitGroup wg;

    Cliente(Barbearia b, int id, WaitGroup wg) {
        this.b = b;
        this.id = id;
        this.wg = wg;
    }

    @Override
    public void run() {
        try {
            entrar();
        } finally {
            wg.done();
        }
    }

    private void entrar() {
        // 1. Região crítica
        b.mutex.down();
        b.validarEstado();

        String nomeAtor = fmt("Cliente #%02d", id);

        if (b.waiting < b.totalCadeiras) {
            // Há cadeira livre: senta na espera
            b.waiting++;
            b.filaEspera.add(id);
            b.validarEstado();

            // 2. Acorda o barbeiro se estiver dormindo
            b.customers.up();

            b.registrarEvento(
                    nomeAtor,
                    "ESPERA",
                    corAmarelo,
                    fmt("Sentou na espera (%d/%d)", b.waiting, b.totalCadeiras),
                    "waiting++ | customers.Up()",
                    fmt("%s obteve mutex.Down(), viu vaga (%d/%d), fez waiting++, acordou barbeiro (customers.Up), liberou mutex.Up() e aguarda em barbers.Down().",
                            nomeAtor, b.waiting, b.totalCadeiras));

            // 3. Libera a região crítica antes de esperar (evita deadlock)
            b.mutex.up();

            // 4. Aguarda o barbeiro chamá-lo
            b.barbers.down();

            // 5. Recebe o corte e vai embora
            receberCorte();
        } else {
            // Lotado: vai embora sem cortar
            b.desistiram++;

            b.registrarEvento(
                    nomeAtor,
                    "LOTADO!",
                    corVermelho,
                    "Sem vagas! Foi embora",
                    "mutex.Up() (Desistiu)",
                    fmt("%s obteve mutex.Down(), viu que waiting == %d (LOTADO!), liberou mutex.Up() e foi embora sem cortar.",
                            nomeAtor, b.totalCadeiras));

            b.mutex.up();
        }
    }

    private void receberCorte() {
        dormir(b.tempoCorte.plusMillis(5));

        b.mutex.down();
        String nomeAtor = fmt("Cliente #%02d", id);
        b.registrarEvento(
                nomeAtor,
                "SAIU",
                corVerde,
                "Cabelo cortado! Saiu feliz",
                "Fim de receberCorte()",
                fmt("%s terminou de receber o corte de cabelo e deixou a barbearia.", nomeAtor));
        b.mutex.up();
    }
}
