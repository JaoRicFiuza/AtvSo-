package barbearia;

/** Equivalente ao sync.WaitGroup do Go: add(), done() (= add(-1)) e esperar(). */
final class WaitGroup {

    private int contador;

    synchronized void add(int delta) {
        contador += delta;
        if (contador < 0) {
            throw new IllegalStateException("WaitGroup com contador negativo");
        }
        if (contador == 0) {
            notifyAll();
        }
    }

    void done() {
        add(-1);
    }

    synchronized void esperar() {
        boolean interrompido = false;
        while (contador > 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                interrompido = true;
            }
        }
        if (interrompido) {
            Thread.currentThread().interrupt();
        }
    }
}
