package barbearia;

/**
 * Semáforo "na unha" (Dijkstra), como no semaforo.go original.
 * Só possui as duas operações clássicas:
 *   - down() (P / wait): decrementa, ou bloqueia a thread se o valor for 0.
 *   - up()   (V / signal): incrementa e acorda uma thread bloqueada.
 * Nota do PDF (pág. 6): não há método para ler o valor atual do semáforo.
 */
final class Semaforo {

    private int valor;

    Semaforo(int valorInicial) {
        this.valor = valorInicial;
    }

    synchronized void down() {
        boolean interrompido = false;
        while (valor == 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                interrompido = true;
            }
        }
        valor--;
        if (interrompido) {
            Thread.currentThread().interrupt();
        }
    }

    synchronized void up() {
        valor++;
        notify();
    }
}
